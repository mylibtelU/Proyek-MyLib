﻿namespace FastFoodDemo
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Register = new System.Windows.Forms.Button();
            this.email = new System.Windows.Forms.TextBox();
            this.PassWord = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.TextBox();
            this.panelUser = new System.Windows.Forms.Panel();
            this.panelEmail = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picemail = new System.Windows.Forms.PictureBox();
            this.picpass = new System.Windows.Forms.PictureBox();
            this.profilepic = new System.Windows.Forms.PictureBox();
            this.Logo2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo2)).BeginInit();
            this.SuspendLayout();
            // 
            // Register
            // 
            this.Register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.Register.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Register.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Register.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Register.Location = new System.Drawing.Point(37, 303);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(250, 32);
            this.Register.TabIndex = 29;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = false;
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.DodgerBlue;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Transparent;
            this.email.Location = new System.Drawing.Point(65, 145);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(216, 16);
            this.email.TabIndex = 26;
            this.email.Text = "Email";
            // 
            // PassWord
            // 
            this.PassWord.BackColor = System.Drawing.Color.DodgerBlue;
            this.PassWord.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PassWord.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassWord.ForeColor = System.Drawing.Color.Transparent;
            this.PassWord.Location = new System.Drawing.Point(65, 213);
            this.PassWord.Name = "PassWord";
            this.PassWord.Size = new System.Drawing.Size(216, 16);
            this.PassWord.TabIndex = 23;
            this.PassWord.Text = "Password";
            // 
            // Username
            // 
            this.Username.BackColor = System.Drawing.Color.DodgerBlue;
            this.Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Username.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.ForeColor = System.Drawing.Color.Transparent;
            this.Username.Location = new System.Drawing.Point(65, 179);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(216, 16);
            this.Username.TabIndex = 20;
            this.Username.Text = "Username";
            // 
            // panelUser
            // 
            this.panelUser.BackColor = System.Drawing.Color.White;
            this.panelUser.Location = new System.Drawing.Point(37, 201);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(250, 1);
            this.panelUser.TabIndex = 21;
            // 
            // panelEmail
            // 
            this.panelEmail.BackColor = System.Drawing.Color.White;
            this.panelEmail.Location = new System.Drawing.Point(37, 167);
            this.panelEmail.Name = "panelEmail";
            this.panelEmail.Size = new System.Drawing.Size(250, 1);
            this.panelEmail.TabIndex = 27;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(37, 235);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 28;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(37, 268);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 32;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.DodgerBlue;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Transparent;
            this.textBox1.Location = new System.Drawing.Point(65, 246);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(216, 16);
            this.textBox1.TabIndex = 31;
            this.textBox1.Text = "Repeat Password";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FastFoodDemo.Properties.Resources.confirm_password;
            this.pictureBox1.Location = new System.Drawing.Point(37, 243);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // picemail
            // 
            this.picemail.Image = global::FastFoodDemo.Properties.Resources.email3;
            this.picemail.Location = new System.Drawing.Point(37, 145);
            this.picemail.Name = "picemail";
            this.picemail.Size = new System.Drawing.Size(22, 16);
            this.picemail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picemail.TabIndex = 25;
            this.picemail.TabStop = false;
            // 
            // picpass
            // 
            this.picpass.Image = global::FastFoodDemo.Properties.Resources.Pass2;
            this.picpass.Location = new System.Drawing.Point(37, 210);
            this.picpass.Name = "picpass";
            this.picpass.Size = new System.Drawing.Size(22, 22);
            this.picpass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picpass.TabIndex = 22;
            this.picpass.TabStop = false;
            // 
            // profilepic
            // 
            this.profilepic.Image = global::FastFoodDemo.Properties.Resources.user1;
            this.profilepic.Location = new System.Drawing.Point(37, 173);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(22, 22);
            this.profilepic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilepic.TabIndex = 19;
            this.profilepic.TabStop = false;
            // 
            // Logo2
            // 
            this.Logo2.BackColor = System.Drawing.Color.DodgerBlue;
            this.Logo2.Image = global::FastFoodDemo.Properties.Resources.logo;
            this.Logo2.Location = new System.Drawing.Point(120, 39);
            this.Logo2.Name = "Logo2";
            this.Logo2.Size = new System.Drawing.Size(81, 72);
            this.Logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logo2.TabIndex = 18;
            this.Logo2.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(324, 415);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.panelEmail);
            this.Controls.Add(this.email);
            this.Controls.Add(this.picemail);
            this.Controls.Add(this.PassWord);
            this.Controls.Add(this.picpass);
            this.Controls.Add(this.panelUser);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.profilepic);
            this.Controls.Add(this.Logo2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox PassWord;
        private System.Windows.Forms.TextBox Username;
        private System.Windows.Forms.PictureBox Logo2;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.PictureBox picemail;
        private System.Windows.Forms.PictureBox profilepic;
        private System.Windows.Forms.PictureBox picpass;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}