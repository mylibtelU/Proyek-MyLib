﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFoodDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Username_Click(object sender, EventArgs e)
        {
            Username.Clear();
            profilepic.BackgroundImage = Properties.Resources.user_ae68788913a1072f01921ad7745c253d;
            panelUser.ForeColor = Color.FromArgb(41, 39, 40);
            Username.ForeColor = Color.FromArgb(41, 39, 40);

            picpass.BackgroundImage = Properties.Resources.password;
            panelPass.ForeColor = Color.WhiteSmoke;
            PassWord.ForeColor = Color.WhiteSmoke;

            picemail.BackgroundImage = Properties.Resources.email_email_a403800cb94da763934eb12b769d2028;
            panelEmail.ForeColor = Color.WhiteSmoke;
            email.ForeColor = Color.WhiteSmoke;



        }

        private void PassWord_Click(object sender, EventArgs e)
        {
            PassWord.Clear();
            PassWord.PasswordChar = '*';
            picpass.BackgroundImage = Properties.Resources.password;
            panelPass.ForeColor = Color.FromArgb(41, 39, 40);
            PassWord.ForeColor = Color.FromArgb(41, 39, 40);

            profilepic.BackgroundImage = Properties.Resources.user_ae68788913a1072f01921ad7745c253d;
            panelUser.ForeColor = Color.WhiteSmoke;
            Username.ForeColor = Color.WhiteSmoke;

            picemail.BackgroundImage = Properties.Resources.email_email_a403800cb94da763934eb12b769d2028;
            panelEmail.ForeColor = Color.WhiteSmoke;
            email.ForeColor = Color.WhiteSmoke;

        }

        private void email_Click(object sender, EventArgs e)
        {
            email.Clear();
            picemail.BackgroundImage = Properties.Resources.email_email_a403800cb94da763934eb12b769d2028;
            panelEmail.ForeColor = Color.FromArgb(41, 39, 40);
            email.ForeColor = Color.FromArgb(41, 39, 40);

            picpass.BackgroundImage = Properties.Resources.password;
            panelPass.ForeColor = Color.WhiteSmoke;
            PassWord.ForeColor = Color.WhiteSmoke;

            profilepic.BackgroundImage = Properties.Resources.user_ae68788913a1072f01921ad7745c253d;
            panelUser.ForeColor = Color.WhiteSmoke;
            Username.ForeColor = Color.WhiteSmoke;

        }
    }
}
