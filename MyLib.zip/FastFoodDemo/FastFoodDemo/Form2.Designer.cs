﻿namespace FastFoodDemo
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Username = new System.Windows.Forms.TextBox();
            this.panelUser = new System.Windows.Forms.Panel();
            this.panelPass = new System.Windows.Forms.Panel();
            this.PassWord = new System.Windows.Forms.TextBox();
            this.panelEmail = new System.Windows.Forms.Panel();
            this.email = new System.Windows.Forms.TextBox();
            this.Login = new System.Windows.Forms.Button();
            this.Register = new System.Windows.Forms.Button();
            this.picemail = new System.Windows.Forms.PictureBox();
            this.picpass = new System.Windows.Forms.PictureBox();
            this.profilepic = new System.Windows.Forms.PictureBox();
            this.Logo2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo2)).BeginInit();
            this.SuspendLayout();
            // 
            // Username
            // 
            this.Username.BackColor = System.Drawing.Color.DodgerBlue;
            this.Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Username.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.ForeColor = System.Drawing.Color.Transparent;
            this.Username.Location = new System.Drawing.Point(66, 139);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(216, 16);
            this.Username.TabIndex = 8;
            this.Username.Text = "Username";
            this.Username.Click += new System.EventHandler(this.Username_Click);
            // 
            // panelUser
            // 
            this.panelUser.BackColor = System.Drawing.Color.White;
            this.panelUser.Location = new System.Drawing.Point(38, 161);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(250, 1);
            this.panelUser.TabIndex = 9;
            // 
            // panelPass
            // 
            this.panelPass.BackColor = System.Drawing.Color.White;
            this.panelPass.Location = new System.Drawing.Point(38, 199);
            this.panelPass.Name = "panelPass";
            this.panelPass.Size = new System.Drawing.Size(250, 1);
            this.panelPass.TabIndex = 12;
            // 
            // PassWord
            // 
            this.PassWord.BackColor = System.Drawing.Color.DodgerBlue;
            this.PassWord.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PassWord.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassWord.ForeColor = System.Drawing.Color.Transparent;
            this.PassWord.Location = new System.Drawing.Point(66, 177);
            this.PassWord.Name = "PassWord";
            this.PassWord.Size = new System.Drawing.Size(216, 16);
            this.PassWord.TabIndex = 11;
            this.PassWord.Text = "Password";
            this.PassWord.Click += new System.EventHandler(this.PassWord_Click);
            // 
            // panelEmail
            // 
            this.panelEmail.BackColor = System.Drawing.Color.White;
            this.panelEmail.Location = new System.Drawing.Point(38, 239);
            this.panelEmail.Name = "panelEmail";
            this.panelEmail.Size = new System.Drawing.Size(250, 1);
            this.panelEmail.TabIndex = 15;
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.DodgerBlue;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Transparent;
            this.email.Location = new System.Drawing.Point(66, 217);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(216, 16);
            this.email.TabIndex = 14;
            this.email.Text = "Email";
            this.email.Click += new System.EventHandler(this.email_Click);
            // 
            // Login
            // 
            this.Login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.Login.FlatAppearance.BorderSize = 0;
            this.Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Login.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Login.Location = new System.Drawing.Point(38, 281);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(250, 32);
            this.Login.TabIndex = 16;
            this.Login.Text = "Sign In";
            this.Login.UseVisualStyleBackColor = false;
            // 
            // Register
            // 
            this.Register.BackColor = System.Drawing.Color.DodgerBlue;
            this.Register.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Register.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Register.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Register.Location = new System.Drawing.Point(38, 329);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(250, 32);
            this.Register.TabIndex = 17;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = false;
            // 
            // picemail
            // 
            this.picemail.Image = global::FastFoodDemo.Properties.Resources.email3;
            this.picemail.Location = new System.Drawing.Point(38, 217);
            this.picemail.Name = "picemail";
            this.picemail.Size = new System.Drawing.Size(22, 16);
            this.picemail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picemail.TabIndex = 13;
            this.picemail.TabStop = false;
            // 
            // picpass
            // 
            this.picpass.Image = global::FastFoodDemo.Properties.Resources.Pass2;
            this.picpass.Location = new System.Drawing.Point(38, 171);
            this.picpass.Name = "picpass";
            this.picpass.Size = new System.Drawing.Size(22, 22);
            this.picpass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picpass.TabIndex = 10;
            this.picpass.TabStop = false;
            // 
            // profilepic
            // 
            this.profilepic.Image = global::FastFoodDemo.Properties.Resources.user1;
            this.profilepic.Location = new System.Drawing.Point(38, 133);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(22, 22);
            this.profilepic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilepic.TabIndex = 5;
            this.profilepic.TabStop = false;
            // 
            // Logo2
            // 
            this.Logo2.BackColor = System.Drawing.Color.DodgerBlue;
            this.Logo2.Image = global::FastFoodDemo.Properties.Resources.logo;
            this.Logo2.Location = new System.Drawing.Point(121, 24);
            this.Logo2.Name = "Logo2";
            this.Logo2.Size = new System.Drawing.Size(81, 72);
            this.Logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logo2.TabIndex = 4;
            this.Logo2.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(340, 454);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.panelEmail);
            this.Controls.Add(this.email);
            this.Controls.Add(this.picemail);
            this.Controls.Add(this.panelPass);
            this.Controls.Add(this.PassWord);
            this.Controls.Add(this.picpass);
            this.Controls.Add(this.panelUser);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.profilepic);
            this.Controls.Add(this.Logo2);
            this.ForeColor = System.Drawing.Color.DodgerBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilepic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox Logo2;
        private System.Windows.Forms.PictureBox profilepic;
        private System.Windows.Forms.TextBox Username;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.Panel panelPass;
        private System.Windows.Forms.TextBox PassWord;
        private System.Windows.Forms.PictureBox picpass;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.PictureBox picemail;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button Register;
    }
}