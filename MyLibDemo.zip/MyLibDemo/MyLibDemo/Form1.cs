﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFoodDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SidePanel.Height = Home.Height;
            SidePanel.Top = Home.Top;
            CustomControl1.BringToFront();
           
        }

        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            SidePanel.Height = Fav.Height;
            SidePanel.Top = Fav.Top;
            userControl51.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void mySecondCustmControl1_Load(object sender, EventArgs e)
        {

        }

        private void firstCustomControl1_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void userControl31_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e) 
        {
            SidePanel.Height = Home.Height;
            SidePanel.Top = Home.Top;
            CustomControl1.BringToFront();
        }

        private void Newest_Click(object sender, EventArgs e)
        {
            SidePanel.Height = Newest.Height;
            SidePanel.Top = Newest.Top;
            userControl311.BringToFront();
        }

        private void userControl311_Load(object sender, EventArgs e)
        {
            
        }

        private void CustomControl1_Load(object sender, EventArgs e)
        {

        }
    }
}
